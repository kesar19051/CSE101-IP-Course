import a1

# Task 1
def findMirrorPoint(p,l):
	p.x=p.x+((-2*l.a*(l.a*p.x + l.b*p.y + l.c))/(l.a*l.a + l.b*l.b))
	p.y=p.y+((-2*l.b*(l.a*p.x + l.b*p.y + l.c))/(l.a*l.a + l.b*l.b))
	return (p.x, p.y)

# Task 2
def checkSides(p1, p2, l1, l2):
	
	p=findMirrorPoint(p1, l1)
	x1=p1.x
	y1=p1.y
	x2=p2.x
	y2=p2.y
	if ((l2.a*x1 + l2.b*y1 + l2.c)/(l2.a*x2 + l2.b*y2 + l2.c)) < 0:
		return True
	else:
		return False


# Task 3
def checkIntersection(c1, c2)​: 
	t=Circle(0,0,1)
	x1=c1.centre_x
	y2=c1.centre_y
	r1=c1.radius
	x2=c2.centre_x
	y2=c2.centre_y
	r2=c2.radius
	C1C2=((x1-x2)*(x1-x2) + (y1-y2)*(y1-y2))**(0.5)
	R=r1+r2
	if C1C2 < R:
		return 'They intersect.'
	else:
		return 'They do not intersect.'
		

