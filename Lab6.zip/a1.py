class Point:
	def __init__(self,x,y):
		self.x = x
		self.y = y

class Line:
	def __init__(self,a,b,c):
		self.a = a
		self.b = b
		self.c = c

class Circle:
	def __init__(self,centre_x,centre_y,radius):
		self.centre_x = centre_x
		self.centre_y = centre_y
		self.radius = radius


		

