import Lab6
import introcs
import a1
#for task 1
p=a1.Point(2,2)
l=a1.Line(1,0,0)
result1=Lab6.findMirrorPoint(a1.Point(2, 2), a1.Line(1, 0, 0))
introcs.assert_equals((-2.0, 2.0), result1)
result2= Lab6.findMirrorPoint(a1.Point(3,4), a1.Line(0, 1, 0))
introcs.assert_equals((3.0, -4.0), result2)
print("Done")

#for task 2
result1=Lab6.checkSides(a1.Point(2,2), a1.Point(3,-3), a1.Line(0,1,0), a1.Line(1,0,0))
introcs.assert_equals(False, result1)
result2=Lab6.checkSides(a1.Point(2,1), a1.Point(4,-3), a1.Line(0,2,0), a1.Line(0,2,0))
introcs.assert_equals(False, result2)
print('Done')

#for task 3
result1=Lab6.checkIntersection(a1.Circle(0,0, 1), a1.Circle(2, 3, 4))
introcs.assert_equals('They intersect.', result1)
result2= Lab6.checkIntersection(a1.Circle(0,1, 1), a1.Circle(2, 3, 4))
introcs.assert_equals('They intersect.', result2)
print('Done')